<?php
/**********************************************************************
  
	Released under the terms of the GNU General Public License, GPL, 
	as published by the Free Software Foundation, either version 3 
	of the License, or (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
    See the License here <http://www.gnu.org/licenses/gpl-3.0.html>.
***********************************************************************/
$page_security = 'SA_OPEN';
$path_to_root="../../..";
include($path_to_root . "/includes/session.inc");

//page(_($help_context = "Allocation Request")); 

include($path_to_root . "/sales/includes/db/credit_status_db.inc");
//include($path_to_root . "/modules/ExtendedHRM/includes/ui/kv_departments.inc" );
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/ui.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include($path_to_root . "/modules/ExtendedHRM/includes/Payroll.inc" );
include_once($path_to_root . "/includes/db_pager.inc");
$version_id = get_company_prefs('version_id');
$js = '';
if($version_id['version_id'] == '2.4.1'){
	if ($SysPrefs->use_popup_windows) 
		$js .= get_js_open_window(900, 500);	

	if (user_use_date_picker()) 
		$js .= get_js_date_picker();
	
}else{
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
}

page(_($help_context = "Leave Request"), @$_REQUEST['popup'], false, "", $js);

?>
<html lang="en">
 <head>
    <link rel="stylesheet" href="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.css" ?>">
    <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-1.10.2.js" ?>"></script>
   <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.js"?>"></script>
</head>
 
 
 </html>
 <?php

simple_page_mode(true);
/*
function can_process() 
{
	/*if (strlen($_POST['no_of_days']) == 0) 
	{
		
		display_error(_("No. of Days cannot be empty."));
		set_focus('no_of_days');
		return false;
	} 	
	
	return true;
}
function can_process1() 
{
	
	/* if (strlen($_POST['no_of_pls']) == 0) 
	{
		display_error(_("No. Of Earned Leaves cannot be empty."));
		set_focus('no_of_pls');
		return false;
	}	
	
	return true; 
}
*/
//-----------------------------------------------------------------------------------


if ($Mode == 'ADD_ITEM' || $Mode == 'UPDATE_ITEM'){
		if(!isset($max_image_size))
			$max_image_size = 500;
		$upload_file = "";
		if (isset($_FILES['upload_file']) && $_FILES['upload_file']['name'] != '') {
		
			$empl_id = $selected_id  ;
			$result = $_FILES['upload_file']['error'];
			$upload_file = 'Yes'; 
			$attr_dir = company_path().'/leave_attachments' ; 
		//display_error($attr_dir); die;	
			if (!file_exists($attr_dir)){
				
				mkdir($attr_dir);
			}
			$filename = company_path().'/leave_attachments';
	//display_error($filename); die;		
			if (!file_exists($filename)){
				mkdir($filename);
			}	
			$doc_ext = substr(trim($_FILES['upload_file']['name']), strlen($_FILES['upload_file']['name']) - 3) ; 
	//display_error($doc_ext); die;		
			if($doc_ext == 'ocx' ) {
				$doc_ext = substr(trim($_FILES['upload_file']['name']), strlen($_FILES['upload_file']['name']) - 4) ; 
			}
			$filename .= "/".empl_img_name($empl_id).'.'.$doc_ext;
	//display_error($filename); die;		
				$kv_file_name = $empl_id.'.'.$doc_ext;
			if ( $_FILES['upload_file']['size'] > ($max_image_size * 1024)) { //File Size Check
				display_warning(_('The file size is over the maximum allowed. The maximum size allowed in KB is') . ' ' . $max_image_size);
				$upload_file ='No';
			} 
			elseif (file_exists($filename)){
				$result = unlink($filename);
				if (!$result) 	{
					display_error(_('The existing CV could not be removed'));
					$upload_file ='No';
				}
			}
			
		/*	if ($upload_file == 'Yes'){
				$result  =  move_uploaded_file($_FILES['upload_file']['tmp_name'], $filename);
				kv_add_or_update_cv($empl_id, $_POST['empl_firstname'], $_POST['cv_title'], $kv_file_name ); 
				display_notification(_("Employee CV has been attached!."));
			} */
			$Ajax->activate('_page_body');
	}	
}
	//add_allocation($_POST['dept_id'],$_POST['desig_group_id'],$_POST['desig_id'],$_POST['employees_id'],$_POST['type_leave'],$_POST['reason'],$today_date,$_POST['from_date'],$_POST['to_date'],$_POST['no_of_days'],$_POST['upload_file'],$_POST['filesize'],$_POST['filetype'],$_POST['unique_name'],$_POST['second_leave_type'],$_POST['second_reason'],$_POST['second_from_date'],$_POST['second_to_date'],$_POST['second_no_of_days']);
	display_notification(_('Leave Request  has been added'));
	$Mode = 'RESET';
//} 

//-----------------------------------------------------------------------------------
/*
if ($Mode=='UPDATE_ITEM' && can_process() ) 
{
	$today_date = date('d-m-Y');
	$query = "SELECT empl_id FROM ".TB_PREF."kv_empl_info WHERE id=".db_escape($_POST['employees_id']);
	$result1= db_query($query);
	$results = db_fetch_row($result1);
	$emp_code = $results[0];
	
	 $tmpname = $_FILES['upload_file']['tmp_name'];
		$dir =  company_path()."/hrm_attachments/".$emp_code.'--'.$today_date."";
		//display_error($dir);
		if (!file_exists($dir))
		{
			mkdir ($dir,0777);
			$index_file = "<?php\nheader(\"Location: ../index.php\");\n?>";
			$fp = fopen($dir."/index.php", "w");
			fwrite($fp, $index_file);
			fclose($fp);
		}
         
		$filename = basename($_FILES['upload_file']['name']);
		//display_error($cart->filename);die;
		$filesize = $_FILES['upload_file']['size'];
		$filetype = $_FILES['upload_file']['type'];
		move_uploaded_file($tmpname, $dir."/".$filename);
	    $_POST['upload_file'] = $filename;
//display_error($status);
$today_date = date('d-m-Y');
	update_allocation($selected_id,$_POST['dept_id'],$_POST['desig_group_id'],$_POST['desig_id'],$_POST['employees_id'],$_POST['type_leave'],$_POST['reason'],$today_date,$_POST['from_date'],$_POST['to_date'],$_POST['no_of_days'],$_POST['upload_file'],$_POST['second_leave_type'],$_POST['second_reason'],$_POST['second_from_date'],$_POST['second_to_date'],$_POST['second_no_of_days']);
	$Mode = 'RESET';
	display_notification(_('Leave Request has been updated'));
} */

//-----------------------------------------------------------------------------------
if ($Mode == 'Delete')
{
	//if (can_delete($selected_id))
	//{
		delete_empl_alloc($selected_id);
		display_notification(_('Leave Request has been deleted'));
	//}
	$Mode = 'RESET';
}

if ($Mode == 'RESET')
{
	$selected_id = -1;
	$sav = get_post('show_inactive');
	unset($_POST);
	$_POST['show_inactive'] = $sav;
}
//-----------------------------------------------------------------------------------
start_form(true);
echo '<br>';
start_table(TABLESTYLE2);
if ($selected_id != -1) 
{
 	if ($Mode == 'Edit') {
		//editing an existing status code
		//display_error($selected_id);die;
		$myrow = get_empl_alloc_single($selected_id);
		$_POST['upload_file']  = $myrow["upload_file"];
	}
	hidden('selected_id', $selected_id);
} 
file_row(_("Attached File") . ":", 'upload_file','upload_file');

end_table(1);
div_end();
submit_add_or_update_center($selected_id == -1, '', 'both');

end_form();

//------------------------------------------------------------------------------------
end_page();
?>			




