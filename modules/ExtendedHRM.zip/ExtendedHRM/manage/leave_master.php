<?php
/**********************************************************************
  
	Released under the terms of the GNU General Public License, GPL, 
	as published by the Free Software Foundation, either version 3 
	of the License, or (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
    See the License here <http://www.gnu.org/licenses/gpl-3.0.html>.
***********************************************************************/
$page_security = 'SA_OPEN';
$path_to_root="../../..";
include($path_to_root . "/includes/session.inc");

page(_($help_context = "Leave Master")); 

include($path_to_root . "/sales/includes/db/credit_status_db.inc");
//include($path_to_root . "/modules/ExtendedHRM/includes/ui/kv_departments.inc" );
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/ui.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include($path_to_root . "/modules/ExtendedHRM/includes/Payroll.inc" );
include($path_to_root . "/includes/ui.inc");

simple_page_mode(true);
if(get_post('_no_of_cls_changed')){
	
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_cls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_cls');
			
		} else{
			$input_error = 0;
		}
	
	
}
if(get_post('_no_of_pls_changed')){
	
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_pls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_pls');
			
		} else{
			$input_error = 0;
		}
	
	
}

if(get_post('_no_of_medical_ls_changed')){
	
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_medical_ls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_medical_ls');
			
		} else{
			$input_error = 0;
		}
	
	
}
if(get_post('_no_of_spl_cls_changed')){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_spl_cls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_spl_cls');
			
		} else{
			$input_error = 0;
		}
}

if(get_post('_no_of_spl_cls_female_changed')){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_spl_cls_female')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_spl_cls_female');
			
		} else{
			$input_error = 0;
		}
}

if(get_post('_no_of_mat_ls_changed')){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_mat_ls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_mat_ls');
			
		} else{
			$input_error = 0;
		}
}

if(get_post('_no_of_patern_ls_changed')){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_patern_ls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_patern_ls');
			
		} else{
			$input_error = 0;
		}
}
?>
<html lang="en">
 <head>
    <link rel="stylesheet" href="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.css" ?>">
    <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-1.10.2.js" ?>"></script>
   <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.js"?>"></script>
</head>
 
 
 </html>
 <?php

function can_process() 
{
	if(!empty($_POST['no_of_cls'])){
	
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_cls')) !=0) {
			
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_cls');
			return false;
			
		} 
}
if(!empty($_POST['no_of_pls_changed'])){
	
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_pls')) !=0) {
			$input_error = 1;
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_pls');
			
			return false;
			
		} 
	
}

if(!empty($_POST['no_of_medical_ls'])){
	
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_medical_ls')) !=0) {
			
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_medical_ls');
			
			return false;
			
		} 
}
if(!empty($_POST['no_of_spl_cls'])){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_spl_cls')) !=0) {
		
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_spl_cls');
			return false;
			
		} 
}

if(!empty($_POST['no_of_spl_cls_female'])){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_spl_cls_female')) !=0) {
			
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_spl_cls_female');
			
			return false;
			
		} 
}

if(!empty($_POST['no_of_mat_ls_changed'])){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_mat_ls')) !=0) {
			
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_mat_ls');
			
			return false;
			
		} 
}

if(!empty($_POST['no_of_patern_ls'])){
	$regex = "/[a-zA-Z*@$%#^&!~()+-\/><.,{}';?<>]/";
		if(preg_match($regex, get_post('no_of_patern_ls')) !=0) {
			
			display_error( _("Only Numericals are allowed."));
			
			set_focus('no_of_patern_ls');
			
				return false;
		} 
}
	
	return true;
}
/* function can_process1() 
{
	
	if (strlen($_POST['no_of_pls']) == 0) 
	{
		display_error(_("No. Of Earned Leaves cannot be empty."));
		set_focus('no_of_pls');
		return false;
	}	
	
	return true;
} */


//-----------------------------------------------------------------------------------

if ($Mode=='ADD_ITEM'  && can_process()) 
{
	//display_error("afdd");die;
	add_leaves($_POST['fisc_year'],$_POST['designation_group_id'],$_POST['desig_id'],$_POST['dept_id'],$_POST['no_of_cls'],$_POST['no_of_pls'],$_POST['no_of_medical_ls'],$_POST['no_of_spl_cls'],$_POST['no_of_spl_cls_female'],$_POST['no_of_mat_ls'],$_POST['no_of_patern_ls']);
	display_notification(_('Leaves  has been added'));
	$Mode = 'RESET';
} 

//-----------------------------------------------------------------------------------

if ($Mode=='UPDATE_ITEM' && can_process() ) 
{
	//display_error("sdff");die;
	update_leaves($selected_id,$_POST['fisc_year'],$_POST['designation_group_id'],$_POST['desig_id'],$_POST['dept_id'],$_POST['no_of_cls'],$_POST['no_of_pls'],$_POST['no_of_medical_ls'],$_POST['no_of_spl_cls'],$_POST['no_of_spl_cls_female'],$_POST['no_of_mat_ls'],$_POST['no_of_patern_ls']);
	$Mode = 'RESET';
	display_notification(_('Leaves has been updated'));
}


//-----------------------------------------------------------------------------------

 /*function can_delete($selected_id)
{
	if (key_in_foreign_table($selected_id, 'debtors_master', 'credit_status'))
	{
		display_error(_("Cannot delete this credit status because customer accounts have been created referring to it."));
		return false;
	}
	
	return true;
} */


//-----------------------------------------------------------------------------------

if ($Mode == 'Delete')
{

	//if (can_delete($selected_id))
	//{
		delete_leave($selected_id);
		display_notification(_('Leave has been deleted'));
	//}
	$Mode = 'RESET';
}

if ($Mode == 'RESET')
{
	$selected_id = -1;
	$sav = get_post('show_inactive');
	unset($_POST);
	$_POST['show_inactive'] = $sav;
}
//-----------------------------------------------------------------------------------

$result = get_leaves(check_value('show_inactive'));
//display_error($result);die;
start_form();
start_table(TABLESTYLE);
$th = array(_("Fiscal Year"),_("Designation Group"),_("Designation Name"),_("Department"),_("No. of CL's"),_("No. of VL's"),_("No. of Medical Leaves"),_("No. of S.CL (Male)"),_("No. of S.CL (Female)"),_("No. of Maternity Leaves"),_("No. of Paternity Leaves"),'','',);
inactive_control_column($th);
table_header($th);

$k = 0;
while ($myrow = db_fetch($result)) 
{
	
	alt_table_row_color($k);	
	//designation_list_cells(_("Select : "), 'desig_group_id', null, true, true);
	label_cell(sql2date($myrow["f_styear"]).'-'.sql2date($myrow["f_endyear"]));
	label_cell($myrow["grp_name"]);
	label_cell($myrow["desig_name"]);
	label_cell($myrow["department"]);
	label_cell($myrow["no_of_cls"]);
	label_cell($myrow["no_of_pls"]);
	label_cell($myrow["no_of_medical_ls"]);
	label_cell($myrow["no_of_spl_cls"]);
	label_cell($myrow["no_of_spl_cls_female"]);
	label_cell($myrow["no_of_mat_ls"]);
	label_cell($myrow["no_of_patern_ls"]);
	//label_cell($status_details);
	//label_cell($disallow_text);
    inactive_control_cell($myrow["leave_id"],$myrow["inactive"],'kv_leave_master', 'leave_id');
 	edit_button_cell("Edit".$myrow['leave_id'], _("Edit"));
 	delete_button_cell("Delete".$myrow['leave_id'], _("Delete"));
	submit_js_confirm("Delete".$myrow["leave_id"], sprintf(_("You are about to delete a Leave Master Do you want to continue?"), $myrow['leave_id']));
	end_row();
}

inactive_control_row($th);
end_table();
echo '<br>';

//-----------------------------------------------------------------------------------

start_table(TABLESTYLE2);
$_POST['no_of_cls']  = 0;
if ($selected_id != -1) 
{
 	if ($Mode == 'Edit') {
		//editing an existing status code
		//display_error($selected_id);die;
		$myrow = get_leaveedit($selected_id);
		//display_error($myrow);
		$_POST['designation_group_id']  = $myrow["designation_group_id"];
		$_POST['desig_id']  = $myrow["desig_id"];
		$_POST['dept_id']  = $myrow["dept_id"];
		$_POST['no_of_cls']  = $myrow["no_of_cls"];
		$_POST['no_of_pls']  = $myrow["no_of_pls"];
		$_POST['no_of_medical_ls']  = $myrow["no_of_medical_ls"];
		$_POST['no_of_spl_cls']  = $myrow["no_of_spl_cls"];
		$_POST['no_of_spl_cls_female']  = $myrow["no_of_spl_cls_female"];
		$_POST['no_of_mat_ls']  = $myrow["no_of_mat_ls"];
		$_POST['no_of_patern_ls']  = $myrow["no_of_patern_ls"];
	}
	hidden('selected_id', $selected_id);
} 
kv_fiscalyears_list_cells(_("Fiscal Year:"), 'fisc_year', null, true);
departments_list_row(_("Department:"), 'dept_id', null, false, true);
desiggroup_list_row(_("Designation Group:"), 'designation_group_id', null, false, true);
$desig_group = $_POST['designation_group_id'];

desig_list_row(_("Desgination:"), 'desig_id', null,false,true,$desig_group);
if(list_updated('designation_group_id')){
	$Ajax->activate('desig_id');
}

//desigroup_list_row( _("Designation :"), 'desigroup_id', null);
//text_row_ex(_("Name:"), 'name', 50);
// leavetype_list_row(_("Leave Type:"), 'type_leave', null, false, false);
text_row_ex(_("No. of Casual Leaves :"), 'no_of_cls', 3,null,null,'00',null," Days",true);

text_row_ex(_("No. of Vacation Leaves :"), 'no_of_pls',3,null,null,'00',null," Days",true);
text_row_ex(_("No. of Medical Leaves :"), 'no_of_medical_ls',3,null,null,'00',null," Days",true);

text_row_ex(_("No. of Special Casual Leaves(Male) :"), 'no_of_spl_cls',3,null,null,'00',null," Days",true);
text_row_ex(_("No. of Special Casual Leaves(Female) :"), 'no_of_spl_cls_female',3,null,null,'00',null," Days",true);
text_row_ex(_("No. of Maternity Leaves :"), 'no_of_mat_ls', 3,null,null,'00',null," Days",true);
text_row_ex(_("No. of Paternity Leaves :"), 'no_of_patern_ls', 3,null,null,'00',null," Days",true);

end_table(1);

submit_add_or_update_center($selected_id == -1, '', 'both');

end_form();

//------------------------------------------------------------------------------------

end_page();

?>
<!-- <p style='padding: 3px;text-align:center;'> <a href='javascript:goBack();'>Back</a></p> -->
<script>
/* $(document).ready(function(){
	
	
	$('input[name=no_of_cls]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});

$(document).ready(function(){
	$('input[name=no_of_pls]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});

$(document).ready(function(){
	$('input[name=no_of_medical_ls]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});

$(document).ready(function(){
	$('input[name=no_of_spl_cls]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});

$(document).ready(function(){
	$('input[name=no_of_spl_cls_female]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});

$(document).ready(function(){
	$('input[name=no_of_mat_ls]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});

$(document).ready(function(){
	$('input[name=no_of_patern_ls]').keypress(function (e){
		 var code =e.keyCode || e.which;
        if (e.which != 8 && e.which != 0 && (e.which < 40 || e.which > 57)) 
        {
          alert("Only Numericals are allowed");
          return false;
        }
    });
});
 */

</script>