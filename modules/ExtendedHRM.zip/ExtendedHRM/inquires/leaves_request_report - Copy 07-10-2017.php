<?php
/****************************************
/*  Author 	: Kvvaradha
/*  Module 	: Extended HRM
/*  E-mail 	: admin@kvcodes.com
/*  Version : 1.0
/*  Http 	: www.kvcodes.com
*****************************************/

$page_security = 'SA_OPEN';
$path_to_root="../../..";

include($path_to_root . "/includes/session.inc");
$version_id = get_company_prefs('version_id');

$js = '';
if($version_id['version_id'] == '2.4.1'){
	if ($SysPrefs->use_popup_windows) 
		$js .= get_js_open_window(900, 500);	

	if (user_use_date_picker()) 
		$js .= get_js_date_picker();
	
}else{
	if ($use_popup_windows)
		$js .= get_js_open_window(900, 500);
	if ($use_date_picker)
		$js .= get_js_date_picker();
}

include_once($path_to_root . "/includes/db_pager.inc");
include_once($path_to_root . "/admin/db/attachments_db.inc");	
include($path_to_root . "/includes/ui.inc");
include($path_to_root . "/modules/ExtendedHRM/includes/Payroll.inc" );
include_once($path_to_root . "/includes/date_functions.inc");
include_once($path_to_root . "/includes/data_checks.inc");
include_once($path_to_root . "/includes/ui/contacts_view.inc");

page(_("Leaves Request Report"), @$_REQUEST['popup'], false, "", $js); 	

check_db_has_employees(_("There is no employee in this system. Kindly Open <a href='".$path_to_root."/modules/ExtendedHRM/manage/employees.php'>Add And Manage Employees</a> to update it"));

simple_page_mode(true); 
?>

<html lang="en">
<style>
.panel-body{padding: 15px 0 0 8px;}
.form-control{width:95%;}
textarea{resize:none;}
</style>
<head>
    <link rel="stylesheet" href="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.css" ?>">
	
    <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-1.10.2.js" ?>"></script>
   <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.js"?>"></script>
   <script src="<?php echo $path_to_root . "/modules/ExtendedHRM/js/jquery-ui.min.js"?>"></script>
   
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
</head>
<body>
<?php 
if (isset($_GET['filterType'])) // catch up external links
	$_POST['filterType'] = $_GET['filterType'];
if (isset($_GET['trans_no']))
	$_POST['trans_no'] = $_GET['trans_no'];

if (isset($_GET['delete_id'])){
	$selected_del_id = $_GET['delete_id'];

	if (key_in_foreign_table($selected_del_id, 'kv_empl_salary', 'empl_id')){
		
		display_error(_("Cannot delete this Employee because Payroll Processed to this employee And it will be  added in the financial Transactions."));
	}else {
		delete_employee($selected_del_id);
		$filename = company_path().'/images/empl/'.empl_img_name($selected_del_id).".jpg";
		if (file_exists($filename))
			unlink($filename);
		display_notification(_("Selected Employee has been deleted."));
		$Ajax->activate('_page_body');	
	}
}

if (get_post('Search'))
{
$to=$_POST['ToDate'];
$from=$_POST['FromDate'];
$status_id=$_POST['leave_status'];
	$query = "SELECT req.*,des_group.name as grp_name,des.name as desig_name,dept.description as department,type.leave_type as leaves,empl.empl_firstname as employee FROM ".TB_PREF."kv_allocation_request AS req  LEFT JOIN ".TB_PREF."kv_desig_group AS des_group ON req.desig_group_id=des_group.id LEFT JOIN ".TB_PREF."designation_master AS des ON req.desig_id=des.id LEFT JOIN ".TB_PREF."kv_departments AS dept ON req.dept_id=dept.id LEFT JOIN ".TB_PREF."kv_type_leave_master AS type ON req.type_leave=type.type_id LEFT JOIN ".TB_PREF."kv_empl_info AS empl  ON empl.id=req.employees_id  WHERE req.from_date >= '" .$from. "'
		AND req.to_date <= '" .$to . "' AND req.status=".db_escape($status_id)."";
		//display_error($query);die;
$res=db_query($query);
	
	$Ajax->activate('trans_tbl');
}

if(list_updated('status')){
//display_error($_POST['status']);
	$Ajax->activate('trans_tbl');
}
div_start('trans_tbl');
// ramesh
start_form();

start_table(TABLESTYLE_NOBORDER);
start_row();

ref_cells(_("Ref"), 'ref', '',null, '', true);
date_cells(_("From:"), 'FromDate', '', null, -1);
date_cells(_("To:"), 'ToDate');
leave_status_list_cells(_("Leave Request Status:"),'leave_status',null);
submit_cells('Search', _("Search"), '', '', 'default');
end_row();
end_table();

echo "<br>";
echo "<br>";

//end
start_table(TABLESTYLE);

$th = array(_("Reference"), _("Employee Name"),
	_("Type of Leave"), _("Reason"), _("From Date"),_("To Date"), _("No.of Days"), _("Uploaded File"), _("Status"),_("Comments"),_(""),_(""),_(""));
table_header($th);


function get_trans($request_id,$type)
{
	$label = $request_id;
	$class ='';
	$id=$request_id;
	$icon = '';
	 $viewer = $path_to_root."modules/ExtendedHRM/manage/";
	if ($type == 'Leave Request')
		$viewer .= "leave_request_view.php?id=".$request_id;
	
	return viewer_link($label, $viewer, $class, $id,  $icon);
	
}

$k = 0; 
$i=1; //row colour counter
while ($myrow = db_fetch($res))
{

	alt_table_row_color($k);

	//$trandate = sql2date($myrow["prevent_id"]);
	//label_cell(get_trans($myrow["allocate_id"],'Leave Request'));
	//label_cell(get_trans_view_str($myrow["type"],$myrow["trans_no"],$myrow['ref']));
	label_cell($myrow["allocate_id"]);
	label_cell($myrow["employee"]);
	if ($myrow["type_leave"] ==1)
	{
		label_cell('Casual');
	}
	else{
		label_cell('Medical Leave');
	}
	label_cell($myrow["reason"]);
	label_cell(dates2sql($myrow["from_date"]));
	label_cell(dates2sql($myrow["to_date"]));
	label_cell($myrow["no_of_days"]);
	//label_cell($myrow["upload_file"]);
	
	 
	
?>
<?php /* $query = "SELECT empl_id FROM ".TB_PREF."kv_empl_info WHERE id=".db_escape($myrow['employees_id']);
    $result1= db_query($query);
	$results = db_fetch_row($result1);
	$emp_code = $results[0];
	
$filename = company_path()."/hrm_attachments/".$emp_code.'--'.$myrow['today_date']."/".$myrow["empl_pic"]; ?>
<td><a class="download" href="download_file.php?fileSource=<?php echo $filename; ?>" target="" title="Download File"><?php echo $myrow["empl_pic"];?> </a></td>
<?php $sql ="SELECT status_id,status_name FROM ".TB_PREF."kv_leave_request_status";

      $res1= db_query($sql); 	  
 ?>
<?php  if(($myrow['status'] !=2) && ($myrow['status'] !=3)){ ?>
<td>

<select name="status<?php echo $i;?>" id="status<?php echo $i;?>" onchange="statuschange(this.value,<?php echo $myrow['allocate_id'];?>,<?php echo $i;?>)">
   <!--  <option value="">Select</option>  -->
	<?php while($result = db_fetch($res1)){
	  ?>  
   <option value="<?php echo $result['status_id']; ?>"><?php echo $result['status_name']; ?></option>
   <?php } ?>
</select>
</td>
<?php } else if($myrow['status'] ==2){ ?>
        <td><?php echo'Approved'; ?></td>
<?php } 


 else if($myrow['status'] ==3){ ?>
<td><?php  echo'Rejected'; ?></td>
 <?php  } ?>
<?php if(empty($myrow['comments'])) { ?>
<td style="display:none" id="test<?php echo $i;?>">
<textarea id="comments<?php echo $i;?>" style="display:none"></textarea>
</td>

<?php } else {
 ?>
<?php if(!empty($myrow["comments"]) ){ ?>
    <td><?php echo $myrow['comments']; ?></td>
<?php } 
else if(($myrow['status'] !=2) && ($myrow['status'] !=1)){ ?>
     
   <td><?php // echo ''; ?></td>  
<?php } else{ ?>

<td><?php echo ''; ?></td> 

  
<?php } }?>
<?php if($myrow['status'] ==1) { ?>
<td id="hidefield<?php echo $i;?>"></td>
<td><input type="button" name="submt" value="Submit" id="submt" style="padding:4px;margin-right:8px;" onclick="select_status(<?php echo $myrow['allocate_id'];?>,<?php echo $i;?>)" /></td>
<?php } else { ?>
<td></td>
<td><?php echo 'Submitted'; ?></td>
<?php } ?>


<?php //} ?>
</td>
 

<?php 	

label_cell('<a onclick="javascript:openWindow(this.href,this.target); return false;" href="'.$path_to_root.'/modules/ExtendedHRM/reports/rep810.php?PARAM_0='.$myrow['allocate_id'].'&rep_v=yes" target="_blank" class="printlink"> <img src="'.$path_to_root.'/themes/default/images/print.png" width="12" height="12" border="0" title="Print"> </a>'); 
	end_row();

	$i++;
}

end_table(2);
div_end();

//----------------------------------------------------------------------------------------

end_page();
?>

</body>
</html>
<script type="text/javascript">

function select_status(request_id,num){
	var request_id = request_id;
	//alert(request_id);
	var status = $('#status'+num+'').val();
	if(status == 3){
	 var comments = $('#comments'+num+'').val();
	 //alert(comments);
	}
	//alert(comments);
	 $.ajax({ 
			type: "POST",
			url:'<?php echo $path_to_root . "/modules/ExtendedHRM/manage/ajax_update_status.php";?>',
			data: {request_id:request_id,status:status,comments : comments}
		}).done(function( data ) { 
			window.location.reload();
		});
	
}
 function statuschange(val,request_id,num){
	var status = val;
//	alert(status);
	
	if(status == 3){
	 $('#comments'+num+'').show();
        $('#test'+num+'').show();
		$('#hidefield'+num+'').hide();
	}
	else{
		$('#comments'+num+'').hide();
		$('#hidefield'+num+'').show();
                $('#test'+num+'').hide();
	}	
  }
</script>
