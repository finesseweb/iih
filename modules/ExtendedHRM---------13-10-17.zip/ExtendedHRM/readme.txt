/****************************************
/*  Author 	: Kvvaradha
/*  Module 	: Extended HRM
/*  E-mail 	: admin@kvcodes.com
/*  Version : 1.0
/*  Http 	: www.kvcodes.com
*****************************************/

INSTALLATION:

Download and extract the ExtendedHRM folder on your modules directory , than follow this steps

1. FrontAccounting -> Setup -> Install/Activate Extensions

   Click on the icon in the right column corresponding to ExtendedHRM

   Extensions drop down box -> Activated for (name of your business)

   Click on "Active" box for ExtendedHRM -> Update

2. FrontAccounting -> Setup -> Access Setup

   Select appropriate role click on HumanResourceManagement header and entry -> Save Role

   Logout and log back in

